import './App.css';
import 'materialize-css/dist/css/materialize.min.css';
import 'materialize-css/dist/js/materialize.min.js';
import { Button, TextInput } from 'react-materialize';
import { useState } from 'react';

function App() {
  const [amount, setAmount] = useState(0);

  function handleClick() {
    const amount = document.getElementById("amount").value;

    setAmount(Number(amount));
  }

  return (
    <div className="App">
      <header className="App-header">
        Currency Converter
      </header>
      <div className="Content">
        <TextInput id="amount" label="Enter an amount" />
        <div id="amountDisplay"><span className="emphasized">Amount:</span> {amount}</div>
        <div id="convertedAmount"><span className="emphasized">Converted amount:</span> {amount * 2}</div>
        <Button
          onClick={handleClick}
        >
          Convert
        </Button>
      </div>
    </div>
  );
}

export default App;
