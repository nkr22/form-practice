I learned a lot in this project. I wish that the fundamentals that we learn in this class were taught to 
us much earlier (perhaps even in the intial 403 class) because through learning the bad, the ugly, and the awful
and trying out the more "outdated" practices we are trying out in this project, I find myself realizing that 
there is a lot of foundation to coding that I have missed in previous projects or classes.

I was able to understand how to use global variables to my advantage and manipulate them throughout my code effectively.
I discovered the follies of passing variables into functions, and you can tell which functions I wrote first because I 
did not realize that there were better ways to find the names, numbers, and objects I was looking to pass. I think to get 
the full experience of building a web app (as rudimentary as it is) and using a new API was very valuable to learning
to tackle big projects.